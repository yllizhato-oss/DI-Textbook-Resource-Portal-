// The landing page is ready.
// Later, change the href in index.html from "#portal"
// to the page/section where your main research portal begins.

console.log("ITE Research Resource Portal loaded.");
